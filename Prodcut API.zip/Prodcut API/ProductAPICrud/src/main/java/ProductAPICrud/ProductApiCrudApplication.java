package ProductAPICrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductApiCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductApiCrudApplication.class, args);
		System.out.println("working Properly...");
	}
      
}
